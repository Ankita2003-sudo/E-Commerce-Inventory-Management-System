
import java.sql.*;
import java.util.Scanner;

public class InventoryManager {
    private static Connection connection;

    public static void main(String[] args) {
        try {
            // Connect to database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory_db", "root", "password");
            Scanner scanner = new Scanner(System.in);
            while(true) {
                System.out.println("1. Add Product");
                System.out.println("2. Update Stock");
                System.out.println("3. View Products");
                System.out.println("4. Exit");
                System.out.print("Enter choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                if(choice == 1) {
                    addProduct(scanner);
                } else if(choice == 2) {
                    updateStock(scanner);
                } else if(choice == 3) {
                    viewProducts();
                } else {
                    break;
                }
            }
            scanner.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addProduct(Scanner scanner) throws SQLException {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // consume newline
        PreparedStatement ps = connection.prepareStatement("INSERT INTO products (name, quantity) VALUES (?, ?)");
        ps.setString(1, name);
        ps.setInt(2, quantity);
        ps.executeUpdate();
        System.out.println("Product added successfully!");
    }

    private static void updateStock(Scanner scanner) throws SQLException {
        System.out.print("Enter product ID to update: ");
        int id = scanner.nextInt();
        System.out.print("Enter new quantity: ");
        int quantity = scanner.nextInt();
        PreparedStatement ps = connection.prepareStatement("UPDATE products SET quantity = ? WHERE id = ?");
        ps.setInt(1, quantity);
        ps.setInt(2, id);
        int rows = ps.executeUpdate();
        if(rows > 0) {
            System.out.println("Stock updated successfully!");
        } else {
            System.out.println("Product not found!");
        }
    }

    private static void viewProducts() throws SQLException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM products");
        System.out.println("ID | Name | Quantity");
        while(rs.next()) {
            System.out.println(rs.getInt("id") + " | " + rs.getString("name") + " | " + rs.getInt("quantity"));
        }
    }
}
